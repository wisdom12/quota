({
	"baseUrl": ".",
	"paths": {
		'jquery': 'lib/jquery'
	},
	"name": "main",
	"out": "main.min.js"
})